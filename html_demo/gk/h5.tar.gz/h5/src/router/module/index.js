import user from "./user";
import order from "./order";
import activity from "./activity";
import admin from "./admin";

export default [...user, ...order, ...activity, ...admin];
