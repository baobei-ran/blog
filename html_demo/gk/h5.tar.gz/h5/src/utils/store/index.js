import cookie from "./cookie";
import localStorage from "./localStorage";

export default {
  cookie,
  localStorage
};
